package ar.org.centro8.curso.java.refugio.entities;

import ar.org.centro8.curso.java.refugio.enums.Sexo;
import ar.org.centro8.curso.java.refugio.enums.Especie;
import ar.org.centro8.curso.java.refugio.enums.Estado;

public class Mascota {
    private int id;
    private String nombre;
    private int edad;
    private Especie especie;
    private String raza;
    private Sexo sexo;
    private Estado estado;
    
    public Mascota() {
    }

    public Mascota(String nombre, int edad, Especie especie, String raza, Sexo sexo, Estado estado) {
        this.nombre = nombre;
        this.edad = edad;
        this.especie = especie;
        this.raza = raza;
        this.sexo = sexo;
        this.estado = estado;
    }

    public Mascota(int id, String nombre, int edad, Especie especie, String raza, Sexo sexo, Estado estado) {
        this.id = id;
        this.nombre = nombre;
        this.edad = edad;
        this.especie = especie;
        this.raza = raza;
        this.sexo = sexo;
        this.estado = estado;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public Especie getEspecie() {
        return especie;
    }

    public void setEspecie(Especie especie) {
        this.especie = especie;
    }

    public String getRaza() {
        return raza;
    }

    public void setRaza(String raza) {
        this.raza = raza;
    }

    public Sexo getSexo() {
        return sexo;
    }

    public void setSexo(Sexo sexo) {
        this.sexo = sexo;
    }

    public Estado getEstado() {
        return estado;
    }

    public void setEstado(Estado estado) {
        this.estado = estado;
    }


    
    
}
