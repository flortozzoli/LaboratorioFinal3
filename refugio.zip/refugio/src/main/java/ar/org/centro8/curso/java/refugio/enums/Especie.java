package ar.org.centro8.curso.java.refugio.enums;

public enum Especie {
    perro,
    gato
}
