package ar.org.centro8.curso.java.refugio.repositories;

public class AdoptanteRepository {
    
}
