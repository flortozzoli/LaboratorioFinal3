package ar.org.centro8.curso.java.refugio.repositories;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import ar.org.centro8.curso.java.refugio.connectors.Connector;
import ar.org.centro8.curso.java.refugio.entities.Adoptante;


public class AdoptanteRepository {
    private Connection conn = Connector.getConnection();
    public void save(Adoptante adoptante) {
        if (adoptante == null) return;
        try (PreparedStatement ps = conn.prepareStatement(
                "insert into adoptantes (nombre, apellido, edad, barrio, mail, idMascota) values (?,?,?,?,?,?)",
                PreparedStatement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, adoptante.getNombre());
            ps.setString(2, adoptante.getApellido());
            ps.setInt(3, adoptante.getEdad());
            ps.setString(4, adoptante.getBarrio());
            ps.setString(5, adoptante.getMail());
            ps.setInt(6, adoptante.getIdMascota());
            ps.execute();
            ResultSet rs = ps.getGeneratedKeys();
            if (rs.next())
                adoptante.setId(rs.getInt(1));
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public List<Adoptante> getAll() {
        List<Adoptante> list = new ArrayList();
        try (ResultSet rs = conn.createStatement().executeQuery("select * from adoptantes")) {
            while (rs.next()) {
                list.add(new Adoptante(
                        rs.getInt("id"),            // id
                        rs.getString("nombre"),     // nombre
                        rs.getString("apellido"),   // apellido
                        rs.getInt("edad"),          // edad
                        rs.getString("barrio"),   // barrio
                        rs.getString("mail"),   // mail
                        rs.getInt("idMascota")        // idMascota
                ));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public Adoptante getById(int id) {
        return getAll()
                .stream()
                .filter(a -> a.getId() == id)
                .findFirst()
                .orElse(new Adoptante());
    }

    public List<Adoptante>getLikeNombre(String nombre){
        if(nombre==null) return new ArrayList();
        return getAll()
                    .stream()
                    .filter(a->a.getNombre().toLowerCase().contains(nombre.toLowerCase()))
                    .toList();      
    }
    public List<Adoptante>getLikeApellido(String apellido){
        if(apellido==null) return new ArrayList();
        return getAll()
                    .stream()
                    .filter(a->a.getApellido().toLowerCase().contains(apellido.toLowerCase()))
                    .toList();     

    }
    
}

