package ar.org.centro8.curso.java.refugio.repositories;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import ar.org.centro8.curso.java.refugio.connectors.Connector;
import ar.org.centro8.curso.java.refugio.entities.Transitante;


public class TransitanteRepository {
    private Connection conn = Connector.getConnection();
    public void save(Transitante transitante) {
        if (transitante == null) return;
        try (PreparedStatement ps = conn.prepareStatement(
                "insert into transitante (nombre, apellido, edad, barrio, idMascota) values (?,?,?,?,?)",
                PreparedStatement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, transitante.getNombre());
            ps.setString(2, transitante.getApellido());
            ps.setInt(3, transitante.getEdad());
            ps.setString(3, transitante.getBarrio());
            ps.setInt(4, transitante.getIdMascota());
            ps.execute();
            ResultSet rs = ps.getGeneratedKeys();
            if (rs.next())
                transitante.setId(rs.getInt(1));
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public List<Transitante> getAll() {
        List<Transitante> list = new ArrayList();
        try (ResultSet rs = conn.createStatement().executeQuery("select * from transitante")) {
            while (rs.next()) {
                list.add(new Transitante(
                        rs.getInt("id"),            // id
                        rs.getString("nombre"),     // nombre
                        rs.getString("apellido"),   // apellido
                        rs.getInt("edad"),          // edad
                        rs.getString("barrio"),   // barrio
                        rs.getInt("idMascota")        // idMascota
                ));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public Transitante getById(int id) {
        return getAll()
                .stream()
                .filter(a -> a.getId() == id)
                .findFirst()
                .orElse(new Transitante(id, null, null, id, null, id));
    }

    public List<Transitante>getLikeApellido(String apellido){
        if(apellido==null) return new ArrayList();
        return getAll()
                    .stream()
                    .filter(a->a.getApellido().toLowerCase().contains(apellido.toLowerCase()))
                    .toList();      

    }

    public List<Transitante>getLikeNombre(String nombre){
        if(nombre==null) return new ArrayList();
        return getAll()
                    .stream()
                    .filter(a->a.getNombre().toLowerCase().contains(nombre.toLowerCase()))
                    .toList();      
    }

    
}
