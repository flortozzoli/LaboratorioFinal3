package ar.org.centro8.curso.java.refugio.test;
import java.sql.Connection;
import java.sql.ResultSet;
import ar.org.centro8.curso.java.refugio.connectors.Connector;

 
public class TestConnector {
    public static void main(String[] args) {
        try (Connection conn=Connector.getConnection()){
            ResultSet rs=conn.createStatement().executeQuery("select version()");
            if(rs.next()) System.out.println(rs.getString(1));
            else System.out.println("No se pudo conectar a la Base!");
        } catch (Exception e) {
            System.out.println("Conectado a la base");
            System.out.println(e);
            System.out.println("No se pudo conectar a la Base!");
        }
    }
}
    

