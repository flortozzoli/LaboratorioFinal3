package ar.org.centro8.curso.java.refugio.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import ar.org.centro8.curso.java.refugio.entities.Adoptante;
import ar.org.centro8.curso.java.refugio.entities.Transitante;
import ar.org.centro8.curso.java.refugio.entities.Mascota;
import ar.org.centro8.curso.java.refugio.repositories.AdoptanteRepository;
import ar.org.centro8.curso.java.refugio.repositories.TransitanteRepository;
import ar.org.centro8.curso.java.refugio.repositories.MascotaRepository;

@Controller
public class WebController {

    private MascotaRepository mascotaRepository = new MascotaRepository();
    private AdoptanteRepository adoptanteRepository = new AdoptanteRepository();
    private TransitanteRepository transitanteRepository = new TransitanteRepository();
    private String mensajeMascota = "Ingresa una nueva mascota";
    private String mensajeAdoptante = "Registrate como Adoptante";
    private String mensajeTransitante = "Registrate como Transitante";

    @GetMapping("/")
    public String getIndex() {
        return "index";
    }

    @GetMapping("/mascotas")
    public String getMascotas(
            @RequestParam(name = "buscarNombre", required = false, defaultValue = "") String buscarNombre,
            Model model) {
        model.addAttribute("mensajeMascota", mensajeMascota);
        model.addAttribute("mascota", new Mascota());
        model.addAttribute("likeNombre", mascotaRepository.getLikeNombre(buscarNombre));
        return "mascotas";
    }

    @GetMapping("/adoptantes")
    public String getAdoptantes(
            @RequestParam(name = "buscarApellido", required = false, defaultValue = "") String buscarApellido,
            Model model) {
        model.addAttribute("mensajeAdoptante", mensajeAdoptante);
        model.addAttribute("adoptante", new Adoptante());
        model.addAttribute("likeApellido", adoptanteRepository.getLikeApellido(buscarApellido));
        model.addAttribute("mascotas", mascotaRepository.getAll());
        return "adoptantes";
    }

    @GetMapping("/transitantes")
    public String getTransitantes(
            @RequestParam(name = "buscarBarrio", required = false, defaultValue = "") String buscarBarrio,
            Model model) {
        model.addAttribute("mensajeTransitante", mensajeTransitante);
        model.addAttribute("transitante", new Transitante());
        model.addAttribute("likeBarrio", transitanteRepository.getLikeBarrio(buscarBarrio));
        model.addAttribute("mascotas",mascotaRepository.getAll());
        return "transitantes";
    }

    @PostMapping("/saveMascota")
    public String save(@ModelAttribute Mascota mascota) {
        try {
            mascotaRepository.save(mascota);
            mensajeMascota = "Se guardo la mascota id: " + mascota.getId();
        } catch (Exception e) {
            mensajeMascota = "ups ocurrio un error";
        }
        return "redirect:mascotas";
    }

    @PostMapping("/saveTransitante")
    public String save(@ModelAttribute Transitante transitante) {
        try {
            transitanteRepository.save(transitante);
            mensajeTransitante = "Se registro el transitante id: " + transitante.getId();
        } catch (Exception e) {
            mensajeTransitante = "ups ocurrio un error";
        }
        return "redirect:transitantes";
    }

    @PostMapping("/saveAdoptante")
    public String save(@ModelAttribute Adoptante adoptante) {
        try {
            adoptanteRepository.save(adoptante);
            mensajeAdoptante = "Se registro el adoptante id: " + adoptante.getId();
        } catch (Exception e) {
            mensajeTransitante = "ups ocurrio un error";
        }
        return "redirect:adoptantes";
    }
}
