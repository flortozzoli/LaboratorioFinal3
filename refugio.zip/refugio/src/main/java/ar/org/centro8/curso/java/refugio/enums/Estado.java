package ar.org.centro8.curso.java.refugio.enums;

public enum Estado {
    adopcion,
    transito
    
}
