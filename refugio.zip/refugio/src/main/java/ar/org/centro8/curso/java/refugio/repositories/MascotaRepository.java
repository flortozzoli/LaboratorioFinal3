package ar.org.centro8.curso.java.refugio.repositories;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import ar.org.centro8.curso.java.refugio.connectors.Connector;
import ar.org.centro8.curso.java.refugio.entities.Mascota;
import ar.org.centro8.curso.java.refugio.enums.Especie;
import ar.org.centro8.curso.java.refugio.enums.Estado;
import ar.org.centro8.curso.java.refugio.enums.Sexo;


public class MascotaRepository {
    private Connection conn = Connector.getConnection();
    public void save(Mascota mascota) {
        if (mascota == null) return;
        try (PreparedStatement ps = conn.prepareStatement(
                "insert into mascotas (nombre, edad, especie, raza, sexo, estado) values (?,?,?,?,?,?)",
                PreparedStatement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, mascota.getNombre());
            ps.setInt(2, mascota.getEdad());
            ps.setString(3, mascota.getEspecie().toString());
            ps.setString(4, mascota.getRaza());
            ps.setString(5, mascota.getSexo().toString());
            ps.setString(6, mascota.getEstado().toString());
            ps.execute();
            ResultSet rs = ps.getGeneratedKeys();
            if (rs.next())
                mascota.setId(rs.getInt(1));
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public List<Mascota> getAll() {
        List<Mascota> list = new ArrayList<>();
        try (ResultSet rs = conn.createStatement().executeQuery("select * from mascotas")) {
            while (rs.next()) {
                list.add(new Mascota(
                        rs.getInt("id"),            // id
                        rs.getString("nombre"),     // nombre
                        rs.getInt("edad"),          // edad
                        Especie.valueOf(rs.getString("especie")),// especie
                        rs.getString("raza"),       // raza
                        Sexo.valueOf(rs.getString("sexo")), // sexo   
                        Estado.valueOf(rs.getString("estado")) // estado        

                )); 
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public Mascota getById(int id) {
        return getAll()
                .stream()
                .filter(a -> a.getId() == id)
                .findFirst()
                .orElse(new Mascota());
    }

    public List<Mascota>getLikeNombre(String nombre){
        if(nombre==null) return new ArrayList<>();
        return getAll()
                    .stream()
                    .filter(a->a.getNombre().toLowerCase().contains(nombre.toLowerCase()))
                    .toList();      
    }
    
    
}

