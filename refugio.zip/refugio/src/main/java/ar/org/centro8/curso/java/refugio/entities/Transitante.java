package ar.org.centro8.curso.java.refugio.entities;

public class Transitante {
    private int id;
    private String nombre;
    private String apellido;
    private int edad;
    private String barrio;
    private String mail;
    private int idMascota;

    public Transitante() {
    }

    @Override
    public String toString() {
        return "Transitante [id=" + id + ", nombre=" + nombre + ", apellido=" + apellido + ", edad=" + edad
                + ", barrio=" + barrio + ", mail=" + mail +", idMascota=" + idMascota + "]";
    }

    public Transitante(String nombre, String apellido, int edad, String barrio, String mail, int idMascota) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.edad = edad;
        this.barrio = barrio;
        this.mail = mail;
        this.idMascota = idMascota;
        
    }

    public Transitante(int id, String nombre, String apellido, int edad, String barrio, String mail, int idMascota) {
        this.id = id;
        this.nombre = nombre;
        this.apellido = apellido;
        this.edad = edad;
        this.barrio = barrio;
        this.mail = mail;
        this.idMascota = idMascota;
        
    }


    public int getId() {
        return id;
    }


    public void setId(int id) {
        this.id = id;
    }


    public String getNombre() {
        return nombre;
    }


    public void setNombre(String nombre) {
        this.nombre = nombre;
    }


    public String getApellido() {
        return apellido;
    }


    public void setApellido(String apellido) {
        this.apellido = apellido;
    }


    public int getEdad() {
        return edad;
    }


    public void setEdad(int edad) {
        this.edad = edad;
    }


    public String getBarrio() {
        return barrio;
    }


    public void setBarrio(String barrio) {
        this.barrio = barrio;
    }

     public String getMail() {
        return mail;
    }


    public void setMail(String mail) {
        this.mail = mail;
    }


    public int getIdMascota() {
        return idMascota;
    }


    public void setIdMascota(int idMascota) {
        this.idMascota = idMascota;
    }
    

    
}
