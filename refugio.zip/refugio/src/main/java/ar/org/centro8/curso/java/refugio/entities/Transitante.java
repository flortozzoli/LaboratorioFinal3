package ar.org.centro8.curso.java.refugio.entities;

public class Transitante {
    
}
