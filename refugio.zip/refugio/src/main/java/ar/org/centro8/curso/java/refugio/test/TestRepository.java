package ar.org.centro8.curso.java.refugio.test;

import ar.org.centro8.curso.java.refugio.entities.Mascota;
import ar.org.centro8.curso.java.refugio.entities.Adoptante;
import ar.org.centro8.curso.java.refugio.entities.Transitante;
import ar.org.centro8.curso.java.refugio.enums.Especie;
import ar.org.centro8.curso.java.refugio.enums.Sexo;
import ar.org.centro8.curso.java.refugio.enums.Estado;
import ar.org.centro8.curso.java.refugio.repositories.MascotaRepository;
import ar.org.centro8.curso.java.refugio.repositories.AdoptanteRepository;
import ar.org.centro8.curso.java.refugio.repositories.TransitanteRepository;

public class TestRepository {

   public static void main(String[] args) {

     
      MascotaRepository msc=new MascotaRepository();
      Mascota mascota=new Mascota("Charu",10,Especie.perro,"Labrador",Sexo.hembra,Estado.adopcion);
      msc.save(mascota);
      System.out.println("***AGREGO UNA MASCOTA***");
      System.out.println(mascota);
      System.out.println("***CONSULTA REPOSITORIO MASCOSTA***");
      msc.getAll().forEach(System.out::println);
      System.out.println("******************************");
      System.out.println(msc.getById(3));
      System.out.println(msc.getLikeNombre("Manu"));
      msc.getLikeNombre("Toby").forEach(System.out::println);
      System.out.println("******************************");
      
   
      
      
      AdoptanteRepository adp = new AdoptanteRepository();
      
      Adoptante adoptante =new Adoptante("Sofia", "Garcia", 26, "Monserrat", "sofigarcia@gmail.com", 3);
      adp.save(adoptante);
      System.out.println("***AGREGO UN ADOPTANTE***");
      System.out.println(adoptante);
      System.out.println("******************************");


      System.out.println("***CONSULTAS REPOSITORIO ADOPTANTE***");
      adp.getAll().forEach(System.out::println);
      System.out.println("*********************************");
      System.out.println(adp.getById(5));
      System.out.println(adp.getLikeApellido("Tozzoli"));
      adp.getLikeNombre("Sofia").forEach(System.out::println);
   
      
      
     
      TransitanteRepository trs = new TransitanteRepository();
      Transitante transitante =new Transitante("Ivana", "Devesa", 33, "Parque patricios", "ivanadevesa@gmailcom", 6);
      trs.save(transitante);
      System.out.println("***AGREGO UN TRANSTITANTE***");
      System.out.println(transitante);

      System.out.println("***CONSULTAS REPOSITORIO TRANSITANTE***");
      trs.getAll().forEach(System.out::println);
      System.out.println("*********************************");
      System.out.println(trs.getById(6));
      System.out.println(trs.getLikeApellido("Cruz"));
      trs.getLikeNombre("Carolina").forEach(System.out::println);
      System.out.println("******************************");

      
        
   } 
}
    

