package ar.org.centro8.curso.java.refugio.test;

import ar.org.centro8.curso.java.refugio.entities.Mascota;
import ar.org.centro8.curso.java.refugio.entities.Adoptante;
import ar.org.centro8.curso.java.refugio.entities.Transitante;
import ar.org.centro8.curso.java.refugio.enums.Especie;
import ar.org.centro8.curso.java.refugio.enums.Sexo;
import ar.org.centro8.curso.java.refugio.enums.Estado;
import ar.org.centro8.curso.java.refugio.repositories.MascotaRepository;
import ar.org.centro8.curso.java.refugio.repositories.AdoptanteRepository;
import ar.org.centro8.curso.java.refugio.repositories.TransitanteRepository;

public class TestRepository {

   public static void main(String[] args) {
        MascotaRepository msc=new MascotaRepository();

        Mascota mascota=new Mascota("Charu",10,Especie.PERRO,"Labrador",Sexo.Hembra,Estado.Adopcion);

        msc.save(mascota);

        System.out.println(mascota);

        msc.getAll().forEach(System.out::println);
        System.out.println("******************************");
        System.out.println(msc.getById(4));
        System.out.println("******************************");
        msc.getLikeNombre("Charu").forEach(System.out::println);



        
   } 
}
    

