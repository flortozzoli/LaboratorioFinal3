package ar.org.centro8.curso.java.refugio.test;

public class TestRepository {
    
}
