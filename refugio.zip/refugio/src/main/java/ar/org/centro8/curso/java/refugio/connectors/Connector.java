package ar.org.centro8.curso.java.refugio.connectors;

import java.sql.Connection;
import java.sql.DriverManager;


public final class Connector {
    private static String driver="com.mysql.jdbc.Driver";
    private static String url="jdbc:mariadb://localhost:3306/refugio";
    private static String user="root";
    private static String pass="";
    private static Connection conn;
    private Connector(){}

    public static synchronized Connection getConnection(){
        try {
            if(conn==null || conn.isClosed()) 
                conn=DriverManager.getConnection(url, user, pass);
                System.out.println("Conectado a la base refugio");
        } catch (Exception e) {
            System.out.println("***************************************");
            System.out.println(e);
            System.out.println("***************************************");
        }
        return conn;
    }

}
    

