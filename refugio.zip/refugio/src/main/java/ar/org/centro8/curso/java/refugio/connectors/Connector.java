package ar.org.centro8.curso.java.refugio.connectors;

public final class Connector {
    
}
