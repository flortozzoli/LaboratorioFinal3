drop database if exists refugio;
create database refugio;
use refugio;

create table mascotas(
id int auto_increment primary key,
especie enum ('gato', 'perro'),
nombre varchar (20) not null,
sexo enum ('macho', 'hembra'),
edad int,
raza varchar(20),
estado enum('adopcion', 'transito') 
);

create table adoptantes(
id int auto_increment primary key,
nombre varchar (20),
apellido varchar (20),
edad int,
barrio varchar (20),
idMascota int not null,
constraint fk_mascotas_adoptante
foreign key(idmascota)
references mascotas(id)
);

create table transitantes(
id int auto_increment primary key,
nombre varchar (20),
apellido varchar (20),
edad int,
barrio varchar (20),
idMascota int not null,
constraint fk_mascotas_transitante
foreign key(idmascota)
references mascotas(id)
);

INSERT INTO mascotas (especie, nombre, sexo, edad, raza, estado) VALUES
('gato', 'Milo', 'macho', 2, 'siamés', 'adopcion'),
('perro', 'Max', 'macho', 3, 'labrador', 'adopcion'),
('gato', 'Luna', 'hembra', 1, 'persa', 'adopcion'),
('perro', 'Bella', 'hembra', 4, 'bulldog', 'adopcion'),
('gato', 'Simba', 'macho', 2, 'angora', 'transito'),
('perro', 'Lucy', 'hembra', 5, 'chihuahua', 'transito'),
('gato', 'Toby', 'macho', 3, 'británico', 'transito'),
('perro', 'Mia', 'hembra', 2, 'poodle', 'transito'),
('gato', 'Oscar', 'macho', 1, 'maine coon', 'adopcion'),
('perro', 'Lola', 'hembra', 6, 'golden retriever', 'adopcion');

INSERT INTO adoptantes (nombre, apellido, edad, barrio, idMascota) VALUES
('Juan', 'Gómez', 30, 'Almagro', 1),
('María', 'López', 25, 'Flores', 2),
('Carlos', 'Rodríguez', 40, 'Villa del parque', 3),
('Laura', 'González', 35, 'La Boca', 4),
('Pedro', 'Fernández', 28, 'Caballito', 5),
('Ana', 'Martínez', 32, 'Almagro', 6),
('José', 'Pérez', 27, 'San Nicolas', 7),
('Sofía', 'Sánchez', 22, 'Villa del parque', 8),
('Luis', 'Torres', 33, 'Villa urquiza', 9),
('Gabriela', 'Ramírez', 29, 'Caballito', 10);

INSERT INTO transitantes (nombre, apellido, edad, barrio, idMascota) VALUES
('Fernando', 'Hernández', 45, 'Almagro', 6),
('Patricia', 'Díaz', 37, 'Flores', 7),
('Andrés', 'Moreno', 39, 'Parque Patricios', 8),
('Carolina', 'Jiménez', 31, 'Villa Urquiza', 9),
('Roberto', 'Silva', 26, 'San Nicolas', 10),
('Isabel', 'Rojas', 34, 'Caballito', 1),
('Javier', 'Vargas', 24, 'La Boca', 2),
('Valeria', 'Navarro', 36, 'Almagro', 3),
('Miguel', 'Romero', 23, 'Barracas', 4),
('Daniela', 'Cruz', 31, 'Oeste', 5);

-- 1) obtener todas las mascotas en adopcion
SELECT * FROM mascotas WHERE estado = 'adopcion';

-- 2) Obtener el nombre y apellido de los adoptantes junto con el id de la mascota adoptada
SELECT a.nombre, a.apellido, m.nombre AS nombre_mascota
FROM adoptantes a
INNER JOIN mascotas m ON a.idMascota = m.id;

-- 3) Obtener el número de mascotas en tránsito agrupadas por especie
SELECT especie, COUNT(*) AS cantidad
FROM mascotas
WHERE estado = 'transito'
GROUP BY especie;


-- 4) Obtener el nombre y barrio de los adoptantes que tienen mascotas de más de 3 años de edad
SELECT a.nombre, a.barrio
FROM adoptantes a
INNER JOIN mascotas m ON a.idMascota = m.id
WHERE m.edad > 3;


-- 5) Obtener el nombre y apellido de los adoptantes que viven en el barrio "Almagro" y tienen mascotas de especie "perro"
SELECT a.nombre, a.apellido
FROM adoptantes a
INNER JOIN mascotas m ON a.idMascota = m.id
WHERE a.barrio = 'Almagro' AND m.especie = 'perro';







 