-- 1) obtener todas las mascotas en adopcion
SELECT * FROM mascotas m WHERE estado = 'adopcion';

-- 2) Obtener el nombre y apellido de los adoptantes junto con el nombre de la mascota adoptada
SELECT a.nombre, a.apellido, m.nombre AS nombre_mascota
FROM adoptantes a
INNER JOIN mascotas m ON a.idMascota = m.id;

-- 3) Obtener el número de mascotas en tránsito agrupadas por especie
SELECT especie, COUNT(*) AS cantidad
FROM mascotas m
WHERE estado = 'transito'
GROUP BY especie;


-- 4) Obtener el nombre y barrio de los adoptantes que tienen mascotas de más de 3 años de edad
SELECT a.nombre, a.barrio
FROM adoptantes a
INNER JOIN mascotas m ON a.idMascota = m.id
WHERE m.edad > 3;


-- 5) Obtener el nombre y apellido de los adoptantes que viven en el barrio "Almagro" y tienen mascotas de especie "perro"
SELECT a.nombre, a.apellido
FROM adoptantes a
INNER JOIN mascotas m ON a.idMascota = m.id
WHERE a.barrio = 'Almagro' AND m.especie = 'perro';
