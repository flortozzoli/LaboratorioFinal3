use refugio; 

INSERT INTO mascotas (especie, nombre, sexo, edad, raza, estado) VALUES
('gato', 'Chino', 'macho', 15, 'siamés esfinje', 'adopcion'),
('perro', 'Max', 'macho', 3, 'labrador', 'adopcion'),
('gato', 'Luna', 'hembra', 1, 'persa', 'adopcion'),
('perro', 'Bella', 'hembra', 4, 'bulldog', 'adopcion'),
('gato', 'Manu', 'macho', 10, 'siamés blue point', 'transito'),
('perro', 'Lucy', 'hembra', 5, 'chihuahua', 'transito'),
('gato', 'Toby', 'macho', 3, 'británico', 'transito'),
('perro', 'Mia', 'hembra', 2, 'poodle', 'transito'),
('gato', 'Oscar', 'macho', 1, 'maine coon', 'adopcion'),
('perro', 'Lola', 'hembra', 6, 'golden retriever', 'adopcion');

INSERT INTO adoptantes (nombre, apellido, edad, barrio, mail, idMascota) VALUES
('Florencia', 'Tozzoli', 34, 'Almagro', 'ftozzoli@gmail.com', 1),
('María', 'López', 25, 'Flores', 'maria.lopez@gmail.com', 2),
('Carlos', 'Rodríguez', 40, 'Villa del parque', 'crodriguez@yahoo.com', 3),
('Laura', 'González', 35, 'La Boca', 'lauragonzalez2@gmail.com', 4),
('Pedro', 'Fernández', 28, 'Caballito', 'peterfernandez@gmail.com', 5),
('Ana', 'Martínez', 32, 'Almagro', 'anitamartinez@gmail.com', 6),
('José', 'Pérez', 27, 'San Nicolas', 'joseperez9@hotmail.com', 7),
('Sofía', 'Sánchez', 22, 'Villa del parque', 'sofisanchez@gmail.com', 8),
('Luis', 'Torres', 33, 'Villa urquiza', 'luitorres22@gmail.com', 9),
('Juan', 'Benavides',35 , 'Caballito', 'jbenavides88@hotmail.com', 10);


INSERT INTO transitantes (nombre, apellido, edad, barrio, mail, idMascota) VALUES
('Fernando', 'Hernández', 45, 'Almagro', 'fhernandez@gmail.com',  6),
('Patricia', 'Díaz', 37, 'Flores', 'patodiaz@hotmail.com', 7),
('Andrés', 'Moreno', 39, 'Parque Patricios', 'amoreno@gmail.com', 8),
('Carolina', 'Jiménez', 31, 'Villa Urquiza', 'carojimenez@hotmail.com', 9),
('Roberto', 'Silva', 26, 'San Nicolas', 'robertsilva@gmail.com', 10),
('Isabel', 'Rojas', 34, 'Caballito', 'irojas@gmail.com', 1),
('Javier', 'Vargas', 24, 'La Boca', 'javiervargas@gmail.com',2),
('Valeria', 'Navarro', 36, 'Almagro', 'valeria.navarro@gmail.com', 3),
('Miguel', 'Romero', 23, 'Barracas', 'miguerRomero@gmail.com', 4),
('Daniela', 'Cruz', 31, 'Villa Devoto','danielacruz@gmail.com', 5);
