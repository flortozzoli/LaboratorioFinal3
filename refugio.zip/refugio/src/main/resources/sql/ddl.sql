create database refugio;
use refugio;

create table mascotas(
id int auto_increment primary key,
especie enum ('perro', 'gato'),
nombre varchar (20) not null,
sexo enum ('macho', 'hembra'),
edad int,
raza varchar(20),
estado enum('adopcion', 'transito') 
);

create table adoptantes(
id int auto_increment primary key,
nombre varchar (20),
apellido varchar (20),
edad int,
barrio varchar (20),
idMascota int not null,
constraint fk_mascotas_adoptante
foreign key(idmascota)
references mascotas(id)
);

create table transitantes(
id int auto_increment primary key,
nombre varchar (20),
apellido varchar (20),
edad int,
barrio varchar (20),
idMascota int not null,
constraint fk_mascotas_transitante
foreign key(idmascota)
references mascotas(id)
);









 