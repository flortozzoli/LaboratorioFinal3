package ar.org.centro8.curso.java.refugio.entities;

public class Adoptante {
    private int id;
    private String nombre;
    private String apellido;
    private int edad;
    private String barrio;
    private int idMascota;


    public Adoptante(int id, String nombre, String apellido, int edad, String barrio, int idMascota) {
        this.id = id;
        this.nombre = nombre;
        this.apellido = apellido;
        this.edad = edad;
        this.barrio = barrio;
        this.idMascota = idMascota;
    }


    public int getId() {
        return id;
    }


    public void setId(int id) {
        this.id = id;
    }


    public String getNombre() {
        return nombre;
    }


    public void setNombre(String nombre) {
        this.nombre = nombre;
    }


    public String getApellido() {
        return apellido;
    }


    public void setApellido(String apellido) {
        this.apellido = apellido;
    }


    public int getEdad() {
        return edad;
    }


    public void setEdad(int edad) {
        this.edad = edad;
    }


    public String getBarrio() {
        return barrio;
    }


    public void setBarrio(String barrio) {
        this.barrio = barrio;
    }


    public int getIdMascota() {
        return idMascota;
    }


    public void setIdMascota(int idMascota) {
        this.idMascota = idMascota;
    }

    
    

    
}
