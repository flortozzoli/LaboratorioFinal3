package ar.org.centro8.curso.java.refugio.enums;

public enum Sexo {
    Macho,
    Hembra
    
}
